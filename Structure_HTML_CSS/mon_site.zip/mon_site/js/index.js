$('[data-fancybox]').fancybox({

    loop: true,

    buttons: ["zoom", "share", "slideShow", "fullScreen", "download", "thumbs", "close"],

    animationEffect: "zoom-in-out"

});