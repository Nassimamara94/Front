// alert("coucou");

$(function(){
    console.log("jQuery est bien chargé");
})

